﻿using LMS.DTOS.Users;
using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;

namespace LMS.Services.Classes
{
    public class ClassService:IClassService
    {
        private HttpClient _httpClient;
        public virtual System.Net.CookieCollection Cookies { get; set; }
        public ClassService() { _httpClient = new HttpClient(); }
        public async Task<string> GetClasses(string tokenvalue)
        {
            Console.WriteLine(tokenvalue);
            string url = GlobalInfo.getClassUrl;
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer",tokenvalue);
            var result = await _httpClient.GetAsync(url);

            var content = await result.Content.ReadAsStringAsync();
            Console.WriteLine(content);
            return content;
        }
     }
}
