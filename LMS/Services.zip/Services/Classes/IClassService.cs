﻿using LMS.DTOS.Users;

namespace LMS.Services.Classes
{
    public interface IClassService
    {
        
        public Task<string> GetClasses(string tokenvalue);
    }
}
